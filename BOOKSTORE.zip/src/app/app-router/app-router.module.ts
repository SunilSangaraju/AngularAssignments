import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';


import { AppPreloadingStrategy } from '../preloading-strategy';
import { LoginComponent } from '../components/login/login.component';


const routes: Routes = [
  { path: '', redirectTo: 'task/login', pathMatch: 'full' },
  {path: 'task/login',  component: LoginComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {useHash: false,
    enableTracing: true,
    preloadingStrategy: AppPreloadingStrategy})],
  exports: [RouterModule],
  providers: [AppPreloadingStrategy]
})
export class AppRouterModule {
}

