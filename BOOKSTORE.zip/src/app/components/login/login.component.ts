import { Component, OnInit } from '@angular/core';
import { User } from '../../model/User';
import { UserService } from '../../services/user.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  user : User;

  constructor(private userService: UserService) { }

  ngOnInit() {
    this.user = new User();
  }

  checkCredentials(){
    console.log("askjdggad");
    this.userService.checkCredentials(this.user).subscribe(
      val => {
         
        alert(val.payload);
                  
      },
      (error) => {
        console.error('Oops, failed!!!', error);
      });
  }

}
