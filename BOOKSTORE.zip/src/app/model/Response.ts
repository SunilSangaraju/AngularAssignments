export class Response{
    payload : any;

    constructor(response?){
        this.payload = response.payload;
    }
    
}