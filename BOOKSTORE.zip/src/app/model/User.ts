export class User{
    emailId : string;
    password : string;
    message: string;

  
        constructor(user?){
            this.emailId = user!=undefined ? user.emailId :"";
            this.password = user!=undefined ? user.password :"";
            this.message = user!=undefined ? user.message :"";
    }
}