import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/empty';
import { User } from '../model/User';
import { Response } from '../model/Response';

@Injectable()
export class UserService {

  

  private host = 'http://localhost:8088';
  private path = '/api';
  constructor(private http: HttpClient) {
  }

  checkCredentials(user: User): Observable<Response> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });
    return this.http.post(this.host + this.path +'/login', user, {headers})
      .map(value => new Response(value));
  }

}
