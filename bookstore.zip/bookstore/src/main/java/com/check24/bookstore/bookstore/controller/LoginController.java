package com.check24.bookstore.bookstore.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.check24.bookstore.bookstore.dto.ResponseDto;
import com.check24.bookstore.bookstore.dto.UserDto;
import com.check24.bookstore.bookstore.exception.BadCredentialsException;
import com.check24.bookstore.bookstore.service.LoginService;

@RequestMapping("/api")
@RestController
@CrossOrigin(origins = "*")
public class LoginController {
	
	@Autowired
	LoginService loginService;
	
	@RequestMapping(value="/login",method=RequestMethod.POST)
	public @ResponseBody ResponseEntity<ResponseDto> checkLoginCredentilas(@RequestBody UserDto userDto){
		checkParameters(userDto);
		ResponseDto responseDto = new ResponseDto();
		responseDto.setPayload(loginService.checkLoginCredentials(userDto.getEmailId(),userDto.getPassword()));
		return new ResponseEntity<ResponseDto>(responseDto,HttpStatus.OK);
	}
	
	public void checkParameters(UserDto userDto){
		if(userDto.getEmailId().equals("")){
			throw new BadCredentialsException("please enter email Id");
		}
		else if(userDto.getPassword().equals("")){
			throw new BadCredentialsException("please enter password");
		}
	}

}
