package com.check24.bookstore.bookstore.service;

import java.util.List;

import com.check24.bookstore.bookstore.dto.BookResponseDto;

public interface BookService {
	
	List<BookResponseDto> getBooks();

}
