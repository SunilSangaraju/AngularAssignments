package com.check24.bookstore.bookstore.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.check24.bookstore.bookstore.entity.User;

@Repository
public interface UsersRepository extends JpaRepository<User,Long> {
	
	User findByemailIdAndPassword(String emailId,String password);
}
