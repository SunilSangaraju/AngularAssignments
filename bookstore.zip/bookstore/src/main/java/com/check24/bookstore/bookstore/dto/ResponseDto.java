package com.check24.bookstore.bookstore.dto;

public class ResponseDto {
	
	private Object payload;

	public Object getPayload() {
		return payload;
	}

	public void setPayload(Object payload) {
		this.payload = payload;
	}
	

}
