package com.check24.bookstore.bookstore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.check24.bookstore.bookstore.dto.UserResponseDto;
import com.check24.bookstore.bookstore.entity.User;
import com.check24.bookstore.bookstore.exception.BadCredentialsException;
import com.check24.bookstore.bookstore.repository.UsersRepository;

@Service("loginService")
public class LoginServiceImpl implements LoginService{
	@Autowired
	UsersRepository usersRepository;

	@Override
	public UserResponseDto checkLoginCredentials(String emailId, String password) {
		System.out.println("emailId="+emailId);
		System.out.println("password="+password);
		User user =usersRepository.findByemailIdAndPassword(emailId, password);
		if(user!=null)
		{
			return new UserResponseDto(user.getEmailId(), "login Successfull");
			
		}
		else
			throw new BadCredentialsException("Invalid Credentials");
		
	}

}
