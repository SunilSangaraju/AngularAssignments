package com.check24.bookstore.bookstore.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.check24.bookstore.bookstore.dto.BookResponseDto;
import com.check24.bookstore.bookstore.repository.BooksRepository;

@Service("BookService")
public class BookServiceImpl implements BookService {
	@Autowired
	BooksRepository booksRepository;
	@Override
	public List<BookResponseDto> getBooks() {
		
		return booksRepository.findAll().stream().map(book ->{
			BookResponseDto bookResponseDto = new BookResponseDto();
			bookResponseDto.setId(book.getId());
			bookResponseDto.setBookId(book.getBookId());
			bookResponseDto.setBookName(book.getName());
			bookResponseDto.setDetails(book.getDetails());
			bookResponseDto.setPrice(book.getPrice());
			bookResponseDto.setImagePath(book.getImage());
			return bookResponseDto;
		}).collect(Collectors.toList());
	}

}
