package com.check24.bookstore.bookstore.service;

import com.check24.bookstore.bookstore.dto.UserResponseDto;

public interface LoginService {
	
	UserResponseDto checkLoginCredentials(String emailId,String password);

}
