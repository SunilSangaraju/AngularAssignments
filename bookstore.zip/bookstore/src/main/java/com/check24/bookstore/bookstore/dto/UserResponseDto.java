package com.check24.bookstore.bookstore.dto;

public class UserResponseDto {
	
	private String emailId;
	private String message;
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public UserResponseDto(){
		
	}
	public UserResponseDto(String emailId, String message) {
		super();
		this.emailId = emailId;
		this.message = message;
	}
	
	
	

}
